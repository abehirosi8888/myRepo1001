package q61;

public interface Foo<T> {
	public T doIt(int i);
}
