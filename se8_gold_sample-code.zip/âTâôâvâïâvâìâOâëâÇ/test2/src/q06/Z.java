package q06;

public class Z extends Y {

	private int b;
	private int c;

	Z(int b, int c) {
		// line n2
		this.b = b;
		this.c = c;
	}

	void doIt() {
		System.out.println("Z");
	}

}
