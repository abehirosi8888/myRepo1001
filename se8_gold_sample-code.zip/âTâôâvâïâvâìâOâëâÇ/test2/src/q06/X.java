package q06;

public abstract class X {

	X() { }

	protected void doIt() {
		System.out.println("X");
	}
}
