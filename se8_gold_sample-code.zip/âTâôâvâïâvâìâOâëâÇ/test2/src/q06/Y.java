package q06;

public class Y extends X {

	private int a;

	Y(int a) {
		// line n1
		this.a = a;
	}
	
	public void doIt() {
		System.out.println("Y");
	}
}
