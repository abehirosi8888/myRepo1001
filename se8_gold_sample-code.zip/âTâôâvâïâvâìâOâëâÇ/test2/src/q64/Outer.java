package q64;

public class Outer {
	static class Inner {
		public final String message = "Hello";
	}
}
