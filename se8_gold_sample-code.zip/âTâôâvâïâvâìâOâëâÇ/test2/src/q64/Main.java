package q64;

public class Main {
	
	public static void main(String[] args) {
		System.out.println(
			// line n1
//			Outer.Inner.message
//			new Outer.Inner().message
//			Outer.new Inner().message
//			new Outer().Inner.message
		);
	}
}
