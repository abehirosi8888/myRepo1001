package q81;

// A.
@FunctionalInterface
public interface Foo {
	void doIt();
}

// B.
//@FunctionalInterface
//public interface Foo {
//	void doIt();
//	boolean equals(Object obj);
//}

// C.
//@FunctionalInterface
//public interface Foo {
//	boolean equals(Object obj);
//}

// D.
//@FunctionalInterface
//public interface Foo {
//}