package q49;

public interface Greeting {
	public void sayHello(String name);
}
