package q23;

public class Foo {
	
	Foo() {
		System.out.println("Foo");
	}
	
	Foo(int i) {
		System.out.println("Foo(" + i + ")");
	}
}