package q23;

public interface Bar {
	Foo doIt(int i);
}