package q66;

public class Main {

	public static void main(String[] args) {		
		Example<String, String> e2 = Example.<String>doIt("OK");
		System.out.println(e2);
	}
}
