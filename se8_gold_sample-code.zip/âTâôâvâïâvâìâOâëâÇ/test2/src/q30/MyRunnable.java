package q30;

public class MyRunnable implements Runnable {

	public void run() {
		System.out.println("OK");
	}
}
