package q83;

public class StringConcatenator {

	public static String result = "";

	public static void concatenate(String str) {
		result += str + " ";
	}
}
