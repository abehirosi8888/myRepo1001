package q11;

public interface X { }
