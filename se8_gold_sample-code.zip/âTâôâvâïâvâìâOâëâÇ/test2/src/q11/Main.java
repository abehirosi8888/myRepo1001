package q11;

public class Main {

	public static void main(String[] args) {
		System.out.print(E.A instanceof E);
		System.out.print(E.B instanceof X);
		System.out.print(E.C instanceof Enum);
	}
}
