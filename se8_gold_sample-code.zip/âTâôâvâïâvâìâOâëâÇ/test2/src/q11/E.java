package q11;

public enum E implements X { // line n1
	A, B, C;
}