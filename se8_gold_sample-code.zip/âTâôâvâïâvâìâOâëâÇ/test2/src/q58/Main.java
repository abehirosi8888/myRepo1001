package q58;

public class Main {

	public static void main(String[] args) {
	
		// A.
		System.out.println(Directions.EAST);
		
		// B.
		System.out.println(Directions.WEST.ordinal());
		
		// C.
//		System.out.println(Directions.indexAt("SOUTH"));
		
		// D.
//		System.out.println(Directions.NORTH.value());
	}
}
