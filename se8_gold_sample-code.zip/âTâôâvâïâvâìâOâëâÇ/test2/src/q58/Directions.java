package q58;

public enum Directions {
	EAST, WEST, SOUTH, NORTH;
}
