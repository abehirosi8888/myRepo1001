package q66;

public class Outer {
	class Inner {
		public void print() {
			System.out.println("Inner: print()");
		}
	}
}