package q62;

public class LengthChecker {
	public static int check(String s1, String s2) {
		return s2.length() - s1.length();
	}
}