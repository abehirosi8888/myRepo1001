package q39;

public interface Flyable {
	Airplane getAirplane(String name);
}