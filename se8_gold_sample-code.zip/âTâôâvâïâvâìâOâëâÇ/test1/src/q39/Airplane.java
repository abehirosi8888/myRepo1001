package q39;

public class Airplane {

	private String name;

	public Airplane(String name) {
		this.name = name;
	}
}