package q07;

public class Parent {

	public void doIt() {
		System.out.println("Parent.doIt()");
	}
}