package q07;

public class Child extends Parent {

	public void doIt() {
		System.out.print("Child.doIt() ");
	}
}