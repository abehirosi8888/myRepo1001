package q35;

public enum Cards {
	SPADE, HEART, CLUB, DIAMOND
};