package q35;

public enum Directions {
	NORTH, EAST, WEST, SOUTH
};
