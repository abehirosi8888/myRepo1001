package q85;

import q78.X;

public abstract class C implements X {
	public void doSomething(String s) {}
}