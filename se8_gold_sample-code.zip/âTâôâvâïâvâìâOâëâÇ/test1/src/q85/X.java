package q85;

public interface X {
	public void doIt(String s);
}