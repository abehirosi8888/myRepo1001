package q85;

import q78.X;

public class B implements X {	
	public void doIt(String s) {}
	public void doThat(String s) {}
	public void doSomething(Integer i) {}
}