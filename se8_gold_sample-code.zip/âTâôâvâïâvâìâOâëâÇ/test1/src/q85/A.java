package q85;

import q78.X;

public class A implements X {
	public void doIt(Integer i) {}
	public String doThis(Integer j) { return 1; }
}