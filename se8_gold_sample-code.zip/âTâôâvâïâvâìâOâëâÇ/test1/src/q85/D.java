package q85;

import q78.X;

public abstract class D implements X {
	public abstract void doIt(String s) { }
	public void doSomething(Integer i) { }
}