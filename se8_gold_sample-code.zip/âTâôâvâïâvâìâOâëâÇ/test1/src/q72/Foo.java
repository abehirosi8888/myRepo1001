package q72;

public class Foo {
	public void doIt() {
		System.out.println("Do it!");
	}
}