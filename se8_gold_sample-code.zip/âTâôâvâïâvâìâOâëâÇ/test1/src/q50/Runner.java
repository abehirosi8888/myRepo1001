package q50;

public class Runner implements Runnable {

	public void run() {
		System.out.println("Running...");
	}
}