package q74;

public class Mobile {

	private String number = "xx-xxxx-xxxx";

	public Mobile(String number) {
		this.number = number;
	}

	public String getNumber() {
		return number;
	}
}