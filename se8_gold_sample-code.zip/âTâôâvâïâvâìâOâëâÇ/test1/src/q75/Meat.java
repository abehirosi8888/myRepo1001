package q75;

public class Meat {

	public final void grill(int min, int temp) { // line n1
	// A.
//	abstract final void grill(int min, int temp) {
	
	// B.
//	public void grill(int min, int temp) {
		// ...
	}

	public void salt() {
		// ...
	}
}
