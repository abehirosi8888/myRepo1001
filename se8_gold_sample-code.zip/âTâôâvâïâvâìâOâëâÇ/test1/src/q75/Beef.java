package q75;

import q85.C;

public class Beef extends Meat {

	public void grill(int minutes, int temperature) { // line n2
	
	// C.
//	@Override
//	public void grill(int minutes, int temperature) {
		
	// D.
//	public final void grill(int minutes, int temperature) {
		// ...
	}

	public void putSauce() {
	}
}