package q13;

public class Main {

	public static void main(String[] args) {
		
		Employee e1 = new Employee(501, "Barden Powell");
		Employee e2 = new Employee(502, "Barden Powell");
		System.out.println(e1.equals(e2)); // line n2
	}
}
