package q73;

public class Main {

	public static void main(String[] args)  {
		
		NumberingSystem ns = new NumberingSystem(8);
		System.out.println(ns.toString());
	}
}
