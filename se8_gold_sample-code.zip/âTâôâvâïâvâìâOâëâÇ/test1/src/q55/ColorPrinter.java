package q55;

public class ColorPrinter extends Printer {
	
	public void print(Paper paper) throws Exception { // line n2
	
	// C.
//	void print(Paper paper) throws Exception {
		
	// D.
//	private void print(Paper paper) throws EmptyInkException {
		super.print(paper);
	}
}