package q55;

@SuppressWarnings("serial")
public class EmptyInkException extends Exception { }