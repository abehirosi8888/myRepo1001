package q05;

public class Example {

	public static void main(String[] args) {
		
		int x = 6;
		int y = -2;
		
		assert (y >= 1) : "Invalid Denominator";
		
		System.out.println(x / y);
	}
}