package q78;

public interface X {
	public void doIt(String s);
}
