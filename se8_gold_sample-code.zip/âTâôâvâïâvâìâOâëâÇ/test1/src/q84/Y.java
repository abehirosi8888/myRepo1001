package q84;

public class Y<T> {
	T t;

	public Y(T t) {
		this.t = t;
	}
}