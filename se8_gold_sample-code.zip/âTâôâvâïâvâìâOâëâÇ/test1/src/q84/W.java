package q84;

public class W<T> {
	static T t;
}