package q84;

public class X<T> {
	T t;

	public X() {
		t = new T();
	}
}
