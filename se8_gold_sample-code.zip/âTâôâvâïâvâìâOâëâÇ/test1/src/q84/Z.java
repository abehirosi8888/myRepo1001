package q84;

public class Z<T> {
	T[] arr;

	public Z() {
		arr = new T[3];
	}
}