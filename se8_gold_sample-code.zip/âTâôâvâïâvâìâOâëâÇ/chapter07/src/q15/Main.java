package q15;

import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {

	public static void main(String[] args) {
		
//		FileSystem.getPath("path");
		FileSystems.getDefault().getPath("path");
//		Path.getPath("path");
//		Paths.get("path");
	}
}
