package q14;

import java.nio.file.FileSystem;
import java.nio.file.FileSystems;

public class Main {
 
	public static void main(String[] args) {
		
//		FileSystem fileSystem = new FileSystem();
//		FileSystem fileSystem = FileSystem.getInstance();
		FileSystem fileSystem = FileSystems.getDefault();
//		FileSystem fileSystem = new FileSystems().getFileSystem();
	}
}
