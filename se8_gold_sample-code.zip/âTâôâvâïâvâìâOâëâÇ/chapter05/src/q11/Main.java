package q11;

public class Main {

	public static void main(String[] args) {
		int x = 0;
		assert x == 1 : "Error Message";
	}
}
