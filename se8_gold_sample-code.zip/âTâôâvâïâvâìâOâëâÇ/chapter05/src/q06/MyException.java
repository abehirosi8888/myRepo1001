package q06;

public class MyException extends Exception {
	// 実装
}
