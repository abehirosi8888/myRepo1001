package q09;

class MyResource {

	public void close() {
		System.out.println("closing");
	}
}
