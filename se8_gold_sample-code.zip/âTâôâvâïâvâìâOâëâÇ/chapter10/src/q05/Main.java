package q05;

import java.util.Locale;

public class Main {

	public static void main(String[] args) {
		
		Locale locale = Locale.JAPAN;
//		Locale locale = new Locale(Locale.JAPAN);
//		Locale locale = Locale.getInstance(Locale.JAPAN); 
//		Locale locale = Locale.getDefault(Locale.JAPAN);
		
		System.out.println(locale);
	}
}
