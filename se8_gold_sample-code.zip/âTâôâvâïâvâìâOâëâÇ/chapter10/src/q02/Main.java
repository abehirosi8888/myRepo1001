package q02;
import java.util.Locale;

public class Main {

	public static void main(String[] args) {
		
//		Locale locale = new Locale();
//		Locale locale = Locale.getInstance();
//		Locale locale = new Locale("ja");
//		Locale locale = Locale.getInstance("en", "US");
//		Locale locale = new Locale("fr", "CA");
//		Locale locale = new Locale("es", "ES", "POSIX");
	}
}
