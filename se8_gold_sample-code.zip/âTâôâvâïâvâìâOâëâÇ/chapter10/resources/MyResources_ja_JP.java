



import java.util.ListResourceBundle;

public class MyResources_ja_JP extends ListResourceBundle {
	
	@Override
	protected Object[][] getContents() {
		return new Object[][] { 
			{ "resource", "MyResources_ja_JP.class" } 
		};
	}
}