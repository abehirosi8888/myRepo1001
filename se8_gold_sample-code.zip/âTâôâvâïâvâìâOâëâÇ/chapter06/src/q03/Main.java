package q03;

import java.time.LocalDate;
import java.time.Month;

public class Main {

	public static void main(String[] args) {
		
//		LocalDate.get(2016, 4, 1);
//		LocalDate.get(2016, Month.APRIL, 1);
		LocalDate.of(2016, 4, 1);
//		LocalDate.of(2016, Month.APRIL, 1);
	}
}
