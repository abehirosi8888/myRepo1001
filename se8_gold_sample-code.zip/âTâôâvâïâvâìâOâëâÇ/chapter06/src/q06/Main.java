package q06;

import java.time.LocalDate;

public class Main {

	public static void main(String[] args) {
		
//		LocalDate.getString("2016-04-01");
//		LocalDate.toString("2016-04-01");
		LocalDate.parse("2016-04-01");
//		LocalDate.format("2016-04-01");
	}
}
