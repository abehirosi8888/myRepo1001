package q18;

@FunctionalInterface
public interface Foo {
	public Integer doIt(String s);
}
