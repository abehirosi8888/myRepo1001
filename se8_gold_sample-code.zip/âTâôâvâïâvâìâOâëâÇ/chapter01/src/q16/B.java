package q16;

public interface B extends A { }
