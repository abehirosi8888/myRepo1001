package q16;

public class D implements B, C {

}
