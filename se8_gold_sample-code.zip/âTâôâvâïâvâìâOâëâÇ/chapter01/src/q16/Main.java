package q16;

public class Main {

	public static void main(String[] args) {
		
		D obj = new D();
		obj.x();
	}
}
