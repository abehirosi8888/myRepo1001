package q17;

public abstract class A {
	abstract void x(); // 抽象メソッド1
	abstract void y(); // 抽象メソッド2
}