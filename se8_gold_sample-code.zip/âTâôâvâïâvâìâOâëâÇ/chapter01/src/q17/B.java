package q17;

public abstract class B extends A {
	@Override void x() {} // 抽象メソッド1の実装
//	@Override void y() {} // 抽象メソッド2の実装
	abstract void y(); // 抽象メソッド2
}
