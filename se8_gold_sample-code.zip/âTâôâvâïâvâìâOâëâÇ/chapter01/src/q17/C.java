package q17;

public abstract class C extends B {
	@Override void y() {} // 抽象メソッド2の実装
}
