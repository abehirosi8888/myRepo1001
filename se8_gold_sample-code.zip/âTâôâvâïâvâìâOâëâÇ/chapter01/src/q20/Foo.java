package q20;

interface Foo {
	void x();
}
