package q20;

public class Main {

	public static void main(String[] args) {

//		anonymous class Foo {
//			public void x() {
//		};
		
//		new class Foo {
//			public void x() {}
//		};

//		class Foo() {
//			public void x() {}
//		};
	
		new Foo() {
			public void x() {}
		};
	}
}
