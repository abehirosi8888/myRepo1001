package q04;

public class Main {

	public static void main(String[] args) {
		
		Child obj = new Child();
		obj.doIt("Hello");
	}
}
