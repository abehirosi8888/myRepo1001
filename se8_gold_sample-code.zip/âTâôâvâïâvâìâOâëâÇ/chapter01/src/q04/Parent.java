package q04;

public class Parent {
	public void doIt(String msg) {
		System.out.println(msg);
	}
}