package q04;

public class Child extends Parent {
	@Override
	public void doIt() {
		System.out.println("Goodbye");
	}
}