package q24;

public enum Stoplight {
	GREEN, YELLOW, RED;
}
