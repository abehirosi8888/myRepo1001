package q25;

public class Main {

	public static void main(String[] args) {
		
		Size size = Size.M;
		System.out.println(size.getValue()); // -> 5
		// 注） 紙面では「System.out.println(size);」となっていますが、上記コードの誤りです。
	}
}
