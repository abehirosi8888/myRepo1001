package q11;

public class A {

	static int x;
	// insert code here
//	A() { x = 1;}
//	{ x = 1; }
	static { x = 1; }
//	init { x = 1; }
	
	public static void main(String[] args) {
		System.out.println(A.x);
	}
}
