package q19;

public class Outer {

	public class Inner {
		public void doIt() {
			System.out.println("Outer.Inner.doIt()");
		}
	}
}
