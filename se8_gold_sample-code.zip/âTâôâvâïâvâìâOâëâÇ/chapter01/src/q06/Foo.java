package q06;

public class Foo {
	public static void main(String[] args) {
		Foo foo = new Foo();
		System.out.println(foo);
	}

	// ========================
	@Override
	public String toString() {
		return "foo";
	}
	// ========================
}