package q15;

public interface A {

	default void x() {
		System.out.println("A.x()");
	};
}
