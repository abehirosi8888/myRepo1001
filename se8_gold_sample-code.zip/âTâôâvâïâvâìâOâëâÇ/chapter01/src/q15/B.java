package q15;

public interface B {

	default void x() {
		System.out.println("B.x()");
	};
}
