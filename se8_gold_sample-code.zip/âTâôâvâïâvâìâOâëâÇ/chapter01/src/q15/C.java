package q15;

public class C implements A, B { }
