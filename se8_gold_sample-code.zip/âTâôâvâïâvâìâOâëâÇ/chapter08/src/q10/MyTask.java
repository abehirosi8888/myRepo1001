package q10;

public class MyTask implements Runnable {
	public void run() {
		System.out.println("OK");
	}
}