package q08;

public class X<T> {

}
