package q08;

public class A {

}
