package q08;

public class B extends A {

}
