package q08;

public class C extends B {

}
