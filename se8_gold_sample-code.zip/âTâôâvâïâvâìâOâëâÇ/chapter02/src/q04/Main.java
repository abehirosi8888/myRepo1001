package q04;

public class Main {

	public static void main(String[] args) {
		
//		Foo foo = new Foo<T>();
//		Foo<int> foo = new Foo<int>();
		Foo<String> foo = new Foo<String>();
//		Foo<Number> foo = new Foo<Long>();
//		Foo<Object[]> foo = new Foo<>();
//		Foo<String> foo = new Foo<>() { };
	}
}
