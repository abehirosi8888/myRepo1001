package q04;

public class Foo<T> {

}
