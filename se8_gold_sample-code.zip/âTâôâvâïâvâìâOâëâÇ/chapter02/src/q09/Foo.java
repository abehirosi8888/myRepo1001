package q09;

public class Foo<T> {

}
