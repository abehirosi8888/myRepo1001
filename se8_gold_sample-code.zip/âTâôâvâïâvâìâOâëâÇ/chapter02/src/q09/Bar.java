package q09;

//class Bar extends Foo<T> {}
class Bar<T> extends Foo<T> {}
//class Bar extends Foo<String> {}
//class Bar<T> extends Foo<Integer> {}