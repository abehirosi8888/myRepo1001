package q12;

import java.util.Arrays;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		List<Double> list = Arrays.asList(1.5, 2.1, 3.3);
//		List<Boolean> list = Arrays.asList(true, false, false, true);
	}
}
