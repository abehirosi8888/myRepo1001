package q24;

public class Product {
	int id;
}
