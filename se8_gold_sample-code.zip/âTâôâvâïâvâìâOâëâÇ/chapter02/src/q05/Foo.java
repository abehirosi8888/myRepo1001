package q05;

public class Foo<T> {

	T t;
//	T obj = new T();
//	T[] array = new T[3];

//	static T t;
	
//	void doIt() {
//		Class<T> klass = T.class;
//	}

//	void doIt(T t) {
//		if (t instanceof T) {
//			/* some code here */ 
//		}
//	}

	T doIt() {
		// some code here
		return t;
	}
}
